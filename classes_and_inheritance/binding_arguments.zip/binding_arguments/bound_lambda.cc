#include <iostream>
#include <string>
#include <vector>
#include <algorithm>
#include <functional>

using namespace std;
using namespace std::placeholders;

bool match(const string& text, const string& value) {
    return text == value;
}

int main() {
	vector<string> texts = {"one", "two", "three", "two", "four", "two", "three"};

	auto total = count_if(texts.begin(), texts.end(), 
						[value="two"](const string& text) {return match(text, value);}
	); 
	
	cout << "The vector contains " << total;
	cout << R"( occurrences of the word "two")" << endl;
}