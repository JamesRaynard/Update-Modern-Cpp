#include <iostream>
#include <string>
#include <vector>
#include <algorithm>

using namespace std;

bool match(const string& text) {
    return text == "two";
}

int main() {
	vector<string> texts = {"one", "two", "three", "two", "four", "two", "three"};

	auto total =  count_if(texts.begin(), texts.end(), match);
	cout << "The vector contains " << total;
	cout << R"( occurrences of the word "two")" << endl;
}